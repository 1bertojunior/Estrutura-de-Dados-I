 /*

    A) V
    B) F - Quando um parâmetro é passado por referência, é usado o & ao chamar a função
    C) F - A ordem dos parâmetro não depende dos valores. A mesma trata apenas de uma escolha para organização  profissional
    D) V
    E) V
    F) V
    G) V
    H) F - Vetor armazena uma sequência de objetos em posições consecutivas na memória e não todas as vezes que se necessitar
colocar um novo valor
    J) V
    K) F - Pilha estática, assim como no vetor, pode conter apenas conjunto de dados do mesmo tipo



 */